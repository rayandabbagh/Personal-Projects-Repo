//=================================================================
// The main program file.
//
// Copyright 2022 Georgia Tech.  All rights reserved.
// The materials provided by the instructor in this course are for
// the use of the students currently enrolled in the course.
// Copyrighted course materials may not be further disseminated.
// This file must not be made publicly available anywhere.
//==================================================================

// External libs
#include <stdlib.h>

// Project includes
#include "globals.h"
#include "hardware.h"
#include "graphics.h"
#include "keyboard.h"


//some LED's to use for debugging.
DigitalOut myled1(LED1);
DigitalOut myled2(LED2);
DigitalOut myled3(LED3);
DigitalOut myled4(LED4);

bool stop;
bool wordle;
bool timed;

Timer gameTimer;
void set_random_seed();

/*
* This function handles the main logic of the game. You should
* initialize the hardware in this function, make calls to 
* functions that update the keyboard and your guess of 
* the word. 
*/
void Play(float frequency, float duration, float volume) {
        speaker.period(1.0/frequency);
        speaker = volume/2.0;
        wait(duration);
        speaker = 0.0;
    }
    
int main()
{
    
    start:
    GameInputs inputs; 
    // First things first: initialize hardware
    ASSERT_P(hardware_init() == ERROR_NONE, "Hardware init failed!");
    
    pc.printf("Program Starting\n");
    
    stop = false;
    //led1 hardware initialization
    
    myled1=1;  
    Timer t;
    int dt; // delta time
    
/* Put code here to initialize the game state:
   1) you will need to use a psuedo random number generator such as
     rand() to randomly select a goal word from the dictionary.
     The random function needs to be seeded before you call rand(),
     otherwise, rand() will always generate the same series of numbers.
     Call the function set_random_seed -- you need to complete its
     definition below.*/
    begin();
    play();
    Play(1000,5,2);
    

    set_random_seed();
    
    intro();
    uLCD.color(WHITE);
    uLCD.locate(0, 13);
    uLCD.printf("1: Wordle");
    uLCD.locate(0, 14);
    uLCD.printf("2: Mathler");
    
    while(1) {
        inputs = read_inputs();
        if (!inputs.b1) {
            wordle = true;
            pc.printf("IN");
            break;
        }
        else if (!inputs.b2) {
            wordle = false;
            pc.printf("IN");
            break;
        }
    }
    uLCD.color(WHITE);
    uLCD.locate(0, 13);
    uLCD.printf("              ");
    uLCD.locate(0, 13);
    uLCD.printf("1: Timed");
    uLCD.locate(0, 14);
    uLCD.printf("              ");
    uLCD.locate(0, 14);
    uLCD.printf("2: Non-Timed");
    
    while(1) {
        Play(500,10,5);
        inputs = read_inputs();
        if (!inputs.b1) {
            uLCD.cls();
            timed = true;
            break;
        }
        else if (!inputs.b2) {
            uLCD.cls();
            timed = false;
            break;
        }
    }
    
    if (wordle) {
        init_keyboard();
    }
    else {
        init_mathler();
    }
    
/*
   2) call init_keyboard() and show start screen*/
    
   
/*   
   3) initialize any other game state that you add.
*/
    uLCD.locate(1,0);
    
   
    uLCD.color(RED);
    if (wordle) {
    uLCD.printf("Correct letters:");
    }
    else {
        uLCD.printf("Equals 40:");
    }
    draw_lower_status();
    
    
/* Insert code into this game loop to complete its implementation:
*/
    gameTimer.start();

    while(1){
        if (timed) {
            uLCD.locate(0, 15);
            double temptime = gameTimer.read_ms() / 1000;
            uLCD.printf("%.0f", temptime);
            if (temptime > 180.0) {
                makeLose();
            }
        }

        t.start(); //start a timer
        inputs = read_inputs(); //read the inputs of the game

        //if (abs(inputs.ax) > 0.15) {
//            if (inputs.ax > 0) {
//                moveleft();
//                wait_ms(abs(1-inputs.ax) * 1000);
//            }
//            else if (inputs.ax < 0) {
//                moveright();
//                wait_ms(abs(1-abs(inputs.ax)) * 1000);
//            }
//        }

        if (stop) return(0);

        if (!inputs.b1) {
            inputs = read_inputs();
            if (!inputs.b2) goto start;
            moveleft();
            while (1) {
                inputs = read_inputs();
                if (inputs.b1) break;
            }
        }
        else if (!inputs.b2) {
            inputs = read_inputs();
            if (!inputs.b1) goto start;
            else if(!inputs.b3) remove_letter();
            else moveright();
            while (1) {
                inputs = read_inputs();
                if (inputs.b2) break;
            }
        }
        else if (!inputs.b3) {
            wait_ms(50);
            inputs = read_inputs();
            if (!inputs.b2) remove_letter();
            else select_letter();

            while (1) {
                inputs = read_inputs();
                if (inputs.b3) {
                  break;
                }
            }
        }

        t.stop();
        dt = t.read_ms();
        if (dt < 100) wait_ms(100 - dt);

        }
    }




/* This should be called in the main function above.
*
* This function sets the random seed for the game using srand(seed).
* One incomplete way to do this is given below: start a Timer and sample it
* to get a seed. The problem is that the same exact time will be read
* every time you reset the mbed.  You need to add code to introduce
* variability into when the timer is stopped.  An easy way to do this
* is to get the user to press a push button to stop the timer at a random
* time.  You can print a prompt to the screen to ask the user to push
* any button to start, then run an infinite while loop that waits for a push 
* button press to break. The Timer is then stopped and read and elapsed time
* used as the seed. (This requires using read_inputs() into a GameInputs variable.)
*/

void set_random_seed() {
    Timer t;
    
    GameInputs game;
    
    t.start(); // start the timer
    wait_ms(225);
    while(true) {
        game = read_inputs();
        
        if (!game.b1 || !game.b2 || !game.b3) {
            
            pc.printf("Enter %d %d %d\n", game.b1, game.b2, game.b3);
            t.stop();
            
            
            break;
        }
    }
    int seed = t.read_ms(); //read the number of milliseconds elapsed between the start and stop
    srand(seed); // use elapsed time as the seed

}
// ===User implementations end===
