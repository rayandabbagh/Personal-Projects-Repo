#include "keyboard.h"
#include "dictionary.h"
#include <string>
//mathler



int b;

LLNode* current;

DLinkedList* key;

Word* target;

int a;

int the_counter;

string guess;



int compareChar(void* first, void* second){
    if(*(char*)first == *(char*)second){
        return 1;
        
    }
    else{
        
        return 0;
    }
}

void makeLose() {
    lose(target->letters);
    stop = true;
}

bool comp(char* x, char* y) {
 
    for (int j = 0; j < 5; j++) {
        if (y[j] != x[j]) 
            return false;
    }
    
    return true;    
}


int findChar(char a_char, char ar[]) {
    for (int z = 0; z < 5; z++) {
        if (ar[z]== a_char) {
            
            return z;
        }
    }
    
    return -1;
}

void copy(int so[], int cop[]) {
    for (int j = 0; j < 5; j++) {
        so[j] = cop[j];
    }
}

void printL() {
    uLCD.text_char(*(char*)getData(current), 8, 15, GREEN);
}

 void init_keyboard()
{

    key = create_dlinkedlist(compareChar);
    
    for (char x = 'a'; x <= 'z'; x++) {
        
        char* character = (char*)malloc(sizeof(x));
        
        *character = x;
        
        insertTail(key, character);
    }
    
    target = &dictionary[rand() % (sizeof(dictionary)/sizeof(dictionary[0]))];
    
    current = key->head;
    
   
    a = 6;
    guess = "";
    b = 5;
    the_counter = 0;
    printL();

}


  void moveleft()
{
    if (current->prev != NULL) {
        current = current->prev;
    }
    else {
        current = key->tail;
    }
    pc.printf("%c",*(char*)getData(current));
  
    printL();
}


 void moveright()
{
    if (current->next == NULL) {
        current = key->head;
    } 
    else {
        current = current->next;
    }
    pc.printf("%c",*(char*)getData(current));
    
    printL();
}

void select_letter()
{   
    guess.push_back(*(char*)getData(current));
    
    uLCD.text_char(*(char*)getData(current), a++, b, WHITE);
    
    if (5 == guess.length()) {
        
        check_word();    
    }
}


 void remove_letter()
{   
    if ( guess.length() >= 1 )
    {
        guess.erase(guess.end()-1, guess.end());
        
        uLCD.text_char(' ', --a, b, WHITE);
    }
}

  void check_word()
{
    uLCD.locate(7,3);
    
    uLCD.printf("     ");
    int counts[5];
    
    copy(counts, target->counts); 
    
    pc.printf("%d %d %d %d %d\n", counts[0], counts[1], counts[2], counts[3], counts[4]);
    
     the_counter++;
     a = 6;
    
    if (comp(&guess[0], target->letters))
    {
        win();
        
        
        stop = true;
        return;
    }
    else
    {
        for (int j = 0; j < 5; j++)
        {
            if (guess[j] == target->letters[j])
            {
                counts[findChar(guess[j], target->unique)]--;
                
                uLCD.text_char(guess[j], j + 6, b, 0x00FF00);
            }
        }
        
        for (int z = 0; z < 5; z++)
        {   
            if (guess[z] != target->letters[z]) {
                int idx = findChar(guess[z], target->unique);
                
                
                if (idx != -1)
                {
                    if (counts[idx] > 0) {
                        counts[idx]--;
                        
                        uLCD.text_char(guess[z], a++, 3, WHITE);
                        
                        uLCD.text_char(guess[z], z + 6, b, 0xFFA500);
                    }
                    else {
                        uLCD.text_char(guess[z], z + 6, b, 0xC0C0C0);
                    }
                }
                else {
                    if (findNode(key, &guess[z])) {
                        moveright();
                        
                        deleteNode(key, findNode(key, &guess[z]));
                    }
                    uLCD.text_char(guess[z], z + 6, b, 0xC0C0C0);
                }
            }
            
        }      
    }
    
    if (the_counter != 6)
    {
         a = 6;
         b++;
         guess = "";
        
    }
    else {
        lose(target->letters);
        
        stop = true;
    }
    
}

void init_mathler()
{

    key = create_dlinkedlist(compareChar);
    
    for (char a = '0'; a <= '9'; a++) {
        char* c = (char*)malloc(sizeof(a));
        *c = a;
        insertTail(key, c);
    }
    
    char a = '+';
    char* c = (char*)malloc(sizeof(a));
    *c = a;
    insertTail(key, c);
    
    a = '-';
    c = (char*)malloc(sizeof(a));
    *c = a;
    insertTail(key, c);
    
    a = '*';
    c = (char*)malloc(sizeof(a));
    *c = a;
    insertTail(key, c);
    
    a = '/';
    c = (char*)malloc(sizeof(a));
    *c = a;
    insertTail(key, c);
    
    target = &mathDict[rand() % (sizeof(mathDict)/sizeof(mathDict[0]))];
    
    current = key->head;
    guess = "";
    a = 6;
    b = 5;
    the_counter = 0;
    
    printL();

}








