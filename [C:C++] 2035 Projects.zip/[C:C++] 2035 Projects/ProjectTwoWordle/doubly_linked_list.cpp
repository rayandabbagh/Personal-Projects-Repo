//=================================================================
// Implementation for DLL module.
//
// Copyright 2022 Georgia Tech.  All rights reserved.
// The materials provided by the instructor in this course are for
// the use of the students currently enrolled in the course.
// Copyrighted course materials may not be further disseminated.
// This file must not be made publicly available anywhere.
//=================================================================
#include <stdlib.h>
#include <stdio.h>
#include "doubly_linked_list.h"

//===========================
/* Creating nodes and lists */
//===========================

LLNode* create_llnode(void* data) {
    LLNode* newNode =(LLNode*)malloc(sizeof(LLNode));
    newNode->data = data;
    newNode->next = NULL;
    newNode->prev = NULL;
    return newNode;
}

DLinkedList* create_dlinkedlist(CompareFunction compare) {
    DLinkedList* newList = (DLinkedList*)malloc(sizeof(DLinkedList));
    newList->head = NULL;
    newList->tail = NULL;
    newList->size = 0;
    newList->compare = compare;
    return newList;
}

//============================
/* Accessing nodes and lists */
//============================

int getSize(DLinkedList* dLinkedList){
        if (dLinkedList == NULL) {
            return 0;
        }
        return dLinkedList->size;
}

LLNode* getHead(DLinkedList* dLinkedList){
        if (dLinkedList == NULL) {
            return NULL;
        }
        return dLinkedList->head;
}

LLNode* getTail(DLinkedList* dLinkedList){
     if (dLinkedList == NULL) {
            return NULL;
        }
        return dLinkedList->tail;
}

LLNode* getNext(LLNode* node){
         if (node == NULL) {
            return NULL;
        }
        return node->next;
}

LLNode* getPrev(LLNode* node){
     if (node == NULL) {
            return NULL;
        }
        return node->prev;
}

void* getData(LLNode* node){
    if (node == NULL) {
            return NULL;
        }
    return node->data;
}

//============================
/* Inserting nodes into lists */
//============================

void insertAfter(DLinkedList* dLinkedList, LLNode* prev_node, void* data){
    
    if(prev_node)
        {
        LLNode* newNode = create_llnode(data);
          if(prev_node->next)
            {
                newNode->next = prev_node->next;
                newNode->prev = prev_node;
                prev_node->next->prev = newNode;
                prev_node->next = newNode;
                
            }  
            else
            {
                prev_node-> next = newNode;
                newNode -> prev = prev_node;
                newNode->next = NULL;
                dLinkedList->tail = newNode;
            }
            dLinkedList->size =  dLinkedList->size+1;
        }
    else
        {
            printf("Error Don't pass a NULL prev_node to insert after\n\r");
        }
}


void insertBefore(DLinkedList* dLinkedList, LLNode* next_node, void* data){
if(next_node)
        {
        
        LLNode* newNode = create_llnode(data);
        
          if(next_node->prev)
            {
               
                newNode->next = next_node;
                newNode->prev = next_node->prev;
                next_node->prev->next = newNode;
                next_node->prev = newNode;

                
            }  
            else
            {
                next_node-> prev = newNode;
                newNode -> next = next_node;
                newNode->prev = NULL;
                dLinkedList->head = newNode;
            }
            dLinkedList->size =  dLinkedList->size+1;
        }
    else
        {
            printf("Error Don't pass a NULL prev_node to insert after\n\r");
        }
}


void insertHead(DLinkedList* dLinkedList, void* data){
   
    if (dLinkedList->size != 0)
        {
            insertBefore(dLinkedList, dLinkedList->head, data);
            return;
        }
    else
        {
            LLNode* head = create_llnode(data);
            dLinkedList->head = head;
            dLinkedList->tail =  head;
            dLinkedList->size =  dLinkedList->size+1;
        }
}

void insertTail(DLinkedList* dLinkedList, void* data){
 if (dLinkedList->size != 0)
        {
            insertAfter(dLinkedList, dLinkedList->tail, data);
            return;
        }
    else
        {
            LLNode* tail = create_llnode(data);
            dLinkedList->tail = tail;
            dLinkedList->head =  tail;
            dLinkedList->size =  dLinkedList->size+1;
        }
}

//============================
/* Looking up nodes in lists */
//============================

LLNode* findNode(DLinkedList* dLinkedList, void* data){
    LLNode* temp = dLinkedList->head;
    while (temp != NULL) {
        if (dLinkedList -> compare(data,temp->data)){
            return temp;
        }
        temp = temp->next;
    }
    return NULL;
}

//===========================
/* Deleting nodes and lists */
//===========================

void deleteNode(DLinkedList* dLinkedList, LLNode* Node){
    if (Node == dLinkedList->head) {
        dLinkedList->head =  Node->next;
        dLinkedList->size--;
        if (Node != dLinkedList->tail) 
            dLinkedList->head->prev = NULL;
        else 
            dLinkedList->tail = NULL;
        free(getData(Node));
        free(Node);
            
    }
    else if (Node == dLinkedList->tail){
        dLinkedList->tail = Node->prev;
        dLinkedList->size--;
        dLinkedList->tail->next = NULL;
        free(getData(Node));
        free(Node);
    }
    else if (Node->next == NULL && Node->prev == NULL){
        dLinkedList->size--;
        free(getData(Node));
        free(Node);
    }
    else {
        Node->prev->next = Node->next;
        Node->next->prev = Node->prev;
        dLinkedList->size--;
        free(getData(Node));
        free(Node);
    }

}

void destroyList(DLinkedList* dLinkedList) {
    LLNode* node = dLinkedList->head;
    LLNode* temp;
    while(node){
        temp = node->next;
        free(getData(node));
        free(node);
        node = temp;
    }
    free(dLinkedList);  
}

//==================
/* Reversing lists */
//==================

void reverse(DLinkedList* dLinkedList){
    LLNode* temp = NULL;
    LLNode* current = dLinkedList->head;
    while (current != NULL) {
       temp = current->prev;
       current->prev = current->next;
       current->next = temp;             
       current = current->prev;
    }
    temp = dLinkedList->head;
    dLinkedList->head = dLinkedList->tail;
    dLinkedList->tail = temp;
    
}