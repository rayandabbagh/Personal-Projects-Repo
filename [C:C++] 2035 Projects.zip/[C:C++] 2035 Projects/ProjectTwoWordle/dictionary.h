/*
* This file contains the dictionary array which is 
* an array of Word structs that hold words that could be
* potential secret words. You may add or remove from the Word
* struct as you see fit for your own implementation.
* You should add more potential secret words to the dictionary.
*/

struct Word {
   char* letters;
   int counts[5];
   char unique[5];
} word;  


Word dictionary[2] = {
    {"speed", {1,1,2,1,0}, {'s','p', 'e', 'd', '!'}},
    {"crane", {1,1,1,1,1}, {'c', 'r', 'a', 'n', 'e'}}
    };
    
Word mathDict[2] = {
    {"7*6-2", {1,1,1,1,1}, {'7','*', '2', '-', '2'}},
    {"9*5-5", {1,1,2,1,0}, {'9','*', '5', '-', '!'}}
};
