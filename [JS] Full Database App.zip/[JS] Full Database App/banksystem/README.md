# Bank System

## Installation Steps
1. Clone this repository.
2. Open the repo folder and run `npm install` to install necessary packages
3. Once the installation is complete, run `npm run dev` to run the website locally
4. Make necessary changes and push to your forked repo (direct and/or pull request)
5. (Optional) Create a pull request to merge the data
